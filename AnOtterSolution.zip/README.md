# 🦦 AnOtterSolution  

### 🇩🇪 Über mich  
Ich bin ein pragmatischer Entwickler mit Sinn fürs Ganze – sozusagen ein Schweizer Taschenmesser für **Elektronik, Mechanik und Software**.  
Mit einem Hintergrund in **Mechatronik** (M.Sc.) und mehreren Jahren Erfahrung als Applikationsingenieur verbinde ich Hardware-Verständnis mit Software-Logik und einem klaren Blick für praktikable Lösungen.  

Ich entwickle gern **komplexe Systeme**, bei denen Technik auf Kreativität trifft – von automatisierten Hardwarelösungen über Embedded-Controller bis hin zu webbasierten Anwendungen und Tools.  
Alle Projekte hier sind **Eigenentwicklungen**, entstanden aus persönlicher Motivation, Neues zu lernen und Ideen in funktionierende Systeme zu verwandeln.  

---

### 🧰 Technologien & Werkzeuge  
**Sprachen:** C, C++, C#, Python, JavaScript, HTML  
**Datenbanken:** SQLite, MySQL, MongoDB, InfluxDB  
**Tools & Frameworks:** Docker, PlatformIO, Flask/FastAPI, Qt, LabView, Grafana, MATLAB/Simulink, Tecap Automated Test PLatform
**CAD / Hardware:** Autodesk Eagle/Inventor, SolidWorks 

---

### 🚀 Projekte (Auswahl)

#### 🪴 [An Otter Grow Control](#)
IoT-basiertes Steuerungssystem zur automatisierten Überwachung und Regelung von Umweltparametern in einem Mini-Gewächshaus.  
Kombiniert **Firmware, Hardware-Design, Frontend, Backend und Datenvisualisierung** in einer modularen Docker-Architektur.  
> *Komplett eigenständige Entwicklung – zeigt Hardware-, Software- und System-Integration.*

|    |    |
|:--:|:--:|
| <img src="images/AnOtterGrowControl-Greenhouse.png" alt="aogc-greenhouse" width=300> | <img src="images/AnOtterGrowControl-Desktop.png" alt="aogc-dashboard-desktop" width=500>

#### 💻 [An Otter PCAP Trainer](#)  
Lern- und Trainings-App für das Python PCAP Examen, mit Trainigsmodi für kapitelbasiertes Training, zufällige Fragen, Prüfungssimulationen und einem integrierten Groq Assistenten (ChatBot) zur Erklärung von Fragen und Themenkomplexen.  

> *Demonstriert Python-, Flask- und einfache Frontend-Kenntnisse sowie Datenbank- und Test-Struktur.*

|    |
|:--:|
|<img src="images/AnOtterPcapTrainer.png" alt="AnOtterPcapTrainer - Example View">

#### ☕ [An Otter Kiosk](#)  

Ein Touch-basiertes, digitales Kassensystem für kleine Vereine und Gemeinschaften auf Basis eines **Raspberry Pi 5 B**. Ermöglicht die Nutzung über ein HMI mit RFID Authentifizierung, sowie über mobile Geräte durch einen eigenen WLAN‑Access‑Point und Einbingung in das lokale Netzwerk über LAN.

> *Verbindet Embedded- und UI-Design mit Datenbank-Logik und Hardware-Integration.*

|    |    |
|:--:|:--:|
| <img src="images/AnOtterKiosk-HMI.png" alt="AnOtterKiosk-HMI" width=500> | <img src="images/AnOtterKiosk-Mobile.png" alt="AnOtterKiosk-HMI" width=200> |

---

### 🧩 Aktuell  
Ich erweitere meine Projekte laufend und experimentiere mit neuen Technologien im Bereich **IoT, Automatisierung und Softwareentwicklung**.  

📍 Magdeburg, Deutschland  
📫 ottersolutions@gmx.de  

---

### 🇬🇧 About Me  
I’m a pragmatic developer with a passion for connecting **hardware, electronics, and software** – a true Swiss-Army-knife-type engineer.  
With a background in **Mechatronics (M.Sc.)** and several years of experience in test and application engineering, I enjoy building systems that merge **practical engineering and digital logic**.  

All showcased projects are **independent developments**, created out of curiosity, passion, and a drive to build working solutions across multiple domains.  

---

### 🧠 Tech Stack  
Languages: C, C++, C#, Python, JavaScript  
Databases: SQLite, MySQL, MongoDB, InfluxDB  
Tools: Docker, PlatformIO, Flask, Qt, Grafana, MATLAB  
Hardware: Eagle, SolidWorks, Inventor  

---

### 🚀 Highlighted Projects  
- **[AnOtter Grow Control](#):** IoT system for automated environmental control – combines hardware, firmware, and full-stack development.  
- **[AnOtter PCAP Trainer](#):** Interactive Python app for PCAP analysis and learning.  
- **[AnOtter Kiosk](#):** Self-service kiosk system with RFID login and 3D-printed housing.  

---

*"Simple ideas. Smart execution. An Otter Solution."* 🦦
